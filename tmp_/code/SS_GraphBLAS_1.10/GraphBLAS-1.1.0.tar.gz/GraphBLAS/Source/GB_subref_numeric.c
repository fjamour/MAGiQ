//------------------------------------------------------------------------------
// GB_subref_numeric: C = A(I,J) or C = (A(J,I))', extract the values
//------------------------------------------------------------------------------

// SuiteSparse:GraphBLAS, Timothy A. Davis, (c) 2017, All Rights Reserved.
// http://suitesparse.com   See GraphBLAS/Doc/License.txt for license.

//------------------------------------------------------------------------------

#include "GB.h"

#include "GB_subref_template.c"

