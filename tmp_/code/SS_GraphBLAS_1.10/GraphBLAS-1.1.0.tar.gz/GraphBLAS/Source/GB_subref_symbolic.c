//------------------------------------------------------------------------------
// GB_subref_symbolic: C = A(I,J), extract the pattern
//------------------------------------------------------------------------------

// SuiteSparse:GraphBLAS, Timothy A. Davis, (c) 2017, All Rights Reserved.
// http://suitesparse.com   See GraphBLAS/Doc/License.txt for license.

//------------------------------------------------------------------------------

#include "GB.h"
#define SYMBOLIC
#include "GB_subref_template.c"

