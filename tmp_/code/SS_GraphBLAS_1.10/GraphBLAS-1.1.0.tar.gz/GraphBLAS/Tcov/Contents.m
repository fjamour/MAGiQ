% GraphBLAS/Tcov/Contents.m:
%
%   gbcover      - compile GraphBLAS for statement coverage testing
%   gbcover_edit - create a version of GraphBLAS for statement coverage tests
%   testcov      - run all GraphBLAS tests, with statement coverage
%   gbshow       - create a test coverage report in cover_gb_report.c

