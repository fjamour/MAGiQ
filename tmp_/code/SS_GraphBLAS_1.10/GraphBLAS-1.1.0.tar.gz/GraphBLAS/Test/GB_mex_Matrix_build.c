//------------------------------------------------------------------------------
// GB_mex_Matrix_build.c: MATLAB interface to GrB_Matrix_build
//------------------------------------------------------------------------------

// SuiteSparse:GraphBLAS, Timothy A. Davis, (c) 2017, All Rights Reserved.
// http://suitesparse.com   See GraphBLAS/Doc/License.txt for license.

//------------------------------------------------------------------------------

#include "GB_mex.h"
#define MATRIX
#include "GB_mx_build_template.c"

