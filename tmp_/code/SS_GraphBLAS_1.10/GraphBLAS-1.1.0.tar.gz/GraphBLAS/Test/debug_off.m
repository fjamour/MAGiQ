function debug_off
%DEBUG_OFF turn off malloc debugging

% SuiteSparse:GraphBLAS, Timothy A. Davis, (c) 2017, All Rights Reserved.
% http://suitesparse.com   See GraphBLAS/Doc/License.txt for license.

global GraphBLAS_debug
GraphBLAS_debug = false ;

