function debug_on
%DEBUG_ON turn on malloc debugging

% SuiteSparse:GraphBLAS, Timothy A. Davis, (c) 2017, All Rights Reserved.
% http://suitesparse.com   See GraphBLAS/Doc/License.txt for license.

global GraphBLAS_debug
GraphBLAS_debug = true ;

