function runtest (testscript)
%RUNTEST run a single GraphBLAS test

%  SuiteSparse:GraphBLAS, Timothy A. Davis, (c) 2017, All Rights Reserved.
%  http://suitesparse.com   See GraphBLAS/Doc/License.txt for license.

eval (testscript) ;

