function test01
%TEST01 test GraphBLAS error handling

% SuiteSparse:GraphBLAS, Timothy A. Davis, (c) 2017, All Rights Reserved.
% http://suitesparse.com   See GraphBLAS/Doc/License.txt for license.

GB_mex_about ;
GB_mex_errors ;

fprintf ('\ntest01: all tests passed\n') ;

